require("./lib/extensions/inputmask.extensions");
require("./lib/extensions/inputmask.date.extensions");
require("./lib/extensions/inputmask.numeric.extensions");
require("./lib/inputmaskElement");
module.exports = require("./lib/inputmask.js");
